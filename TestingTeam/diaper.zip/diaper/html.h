/*
  ESP32 HTML WebServer Page Code
  http:://www.electronicwings.com
*/

const char html_page[] PROGMEM = R"rawString(
<!DOCTYPE html>
<html>
  <style>
    body {font-family: sans-serif;}
    h1 {text-align: center; font-size: 30px;}
    p {text-align: center; color: #4CAF50; font-size: 40px;}
  </style>
  
<body>
  <h1>Diaper Moisture</h1><br>
  <p>Moisture Level :<span id="MoistureVal">0</span>%</p><br>

  <script>
    setInterval(function() {
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          document.getElementById("MoistureVal").innerHTML = this.responseText;
        }
      };
      xhttp.open("GET", "readMoisture", true);
      xhttp.send();
    },50);
  </script>
</body>
</html>
)rawString";